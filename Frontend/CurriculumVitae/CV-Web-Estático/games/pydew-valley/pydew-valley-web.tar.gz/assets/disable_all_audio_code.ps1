# ==========================================================
# DESACTIVAR TODO EL AUDIO EN LOS SCRIPTS PYTHON
# Crea copias .audio_backup antes de modificar cada archivo.
# ==========================================================

$projectRoot = Get-Location

$pythonFiles = Get-ChildItem `
    -Path $projectRoot `
    -Recurse `
    -Filter "*.py" `
    -File |
    Where-Object {
        $_.FullName -notmatch "\\build\\" -and
        $_.FullName -notmatch "\\dist\\" -and
        $_.FullName -notmatch "\\__pycache__\\"
    }

$totalFilesModified = 0
$totalBlocksDisabled = 0
$totalCallsDisabled = 0

foreach ($file in $pythonFiles) {

    $lines = Get-Content -LiteralPath $file.FullName
    $newLines = New-Object System.Collections.Generic.List[string]
    $soundVariables = New-Object System.Collections.Generic.HashSet[string]

    # Detectar variables asignadas mediante pygame.mixer.Sound
    foreach ($line in $lines) {

        if ($line -match '^\s*(self\.[A-Za-z_][A-Za-z0-9_]*|[A-Za-z_][A-Za-z0-9_]*)\s*=\s*pygame\.mixer\.Sound') {
            [void]$soundVariables.Add($matches[1])
        }
    }

    $insideSoundBlock = $false
    $parenthesisBalance = 0
    $fileModified = $false

    foreach ($line in $lines) {

        $trimmed = $line.TrimStart()

        # Ya comentada: conservarla tal cual
        if ($trimmed.StartsWith("#")) {
            $newLines.Add($line)
            continue
        }

        # Inicio de una carga pygame.mixer.Sound(...)
        if (-not $insideSoundBlock -and $line -match 'pygame\.mixer\.Sound\s*\(') {

            $insideSoundBlock = $true
            $fileModified = $true
            $totalBlocksDisabled++

            $openCount = ([regex]::Matches($line, '\(')).Count
            $closeCount = ([regex]::Matches($line, '\)')).Count
            $parenthesisBalance = $openCount - $closeCount

            $indent = $line.Substring(0, $line.Length - $trimmed.Length)
            $newLines.Add("${indent}# AUDIO WEB DESACTIVADO: $trimmed")

            if ($parenthesisBalance -le 0) {
                $insideSoundBlock = $false
            }

            continue
        }

        # Resto de líneas de una carga Sound multilínea
        if ($insideSoundBlock) {

            $openCount = ([regex]::Matches($line, '\(')).Count
            $closeCount = ([regex]::Matches($line, '\)')).Count
            $parenthesisBalance += $openCount - $closeCount

            $indent = $line.Substring(0, $line.Length - $trimmed.Length)
            $newLines.Add("${indent}# AUDIO WEB DESACTIVADO: $trimmed")

            if ($parenthesisBalance -le 0) {
                $insideSoundBlock = $false
            }

            continue
        }

        # Desactivar .play() y .set_volume() solo para variables de sonido detectadas
        $disableThisLine = $false

        foreach ($soundVariable in $soundVariables) {

            $escapedVariable = [regex]::Escape($soundVariable)

            if (
                $line -match "$escapedVariable\s*\.\s*play\s*\(" -or
                $line -match "$escapedVariable\s*\.\s*set_volume\s*\("
            ) {
                $disableThisLine = $true
                break
            }
        }

        # También desactivar pygame.mixer.music
        if ($line -match 'pygame\.mixer\.music\.') {
            $disableThisLine = $true
        }

        if ($disableThisLine) {

            $indent = $line.Substring(0, $line.Length - $trimmed.Length)
            $newLines.Add("${indent}# AUDIO WEB DESACTIVADO: $trimmed")

            $fileModified = $true
            $totalCallsDisabled++

            continue
        }

        $newLines.Add($line)
    }

    if ($fileModified) {

        $backupPath = "$($file.FullName).audio_backup"

        if (-not (Test-Path -LiteralPath $backupPath)) {
            Copy-Item -LiteralPath $file.FullName -Destination $backupPath
        }

        Set-Content `
            -LiteralPath $file.FullName `
            -Value $newLines `
            -Encoding UTF8

        Write-Host "Modificado: $($file.FullName)"
        $totalFilesModified++
    }
}

Write-Host ""
Write-Host "=============================================="
Write-Host "Audio desactivado en todo el proyecto."
Write-Host "Scripts modificados: $totalFilesModified"
Write-Host "Cargas Sound comentadas: $totalBlocksDisabled"
Write-Host "Llamadas play/set_volume comentadas: $totalCallsDisabled"
Write-Host "=============================================="