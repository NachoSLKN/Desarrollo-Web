$audioFolder = ".\project\audio"

Get-ChildItem $audioFolder -Filter *.mp3 | ForEach-Object {

    $newName = $_.Name + ".disabled"

    Rename-Item $_.FullName $newName

    Write-Host "Renombrado:" $_.Name "->" $newName
}

Write-Host ""
Write-Host "Todos los MP3 han sido deshabilitados."