# Restaura todos los archivos .wav.disabled

$audioFolder = ".\project\audio"

Get-ChildItem $audioFolder -Filter *.wav.disabled | ForEach-Object {

    $newName = $_.FullName -replace "\.disabled$", ""

    Rename-Item $_.FullName $newName

    Write-Host "Restaurado: $($_.Name)"
}

Write-Host ""
Write-Host "Todos los WAV han sido restaurados."