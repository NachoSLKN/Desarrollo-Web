﻿from audio_helper import load_sound
import pygame
from settings import *
from pytmx.util_pygame import load_pygame
from support import *
from random import choice
from resource_path import resource_path

class SoilTile(pygame.sprite.Sprite):
    def __init__(self,pos,surf,groups):
        super().__init__(groups)
        self.image=surf
        self.rect = self.image.get_rect(topleft = pos)
        self.z = LAYERS['soil']

class WaterTile(pygame.sprite.Sprite): #Clase idÃ©ntica a la class Generic pero por mantener cÃ³digo limpio y ordenado
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft = pos)
        self.z = LAYERS['soil water']

class Plant(pygame.sprite.Sprite):
    
    def __init__(self,plant_type, groups, soil, check_watered):
        super().__init__(groups)
        
        # setup
        self.plant_type = plant_type
        self.frames = import_folder(f'project/graphics/fruit/{plant_type}')
        self.check_watered = check_watered
        self.soil = soil
        
        # plant growing
        self.age = 0
        self.max_age = len(self.frames) - 1
        self.grow_speed = GROW_SPEED[plant_type]
        self.harvestable = False
        
        #sprite setup
        self.image = self.frames[self.age]
        self.y_offset = -16 if plant_type == 'corn' else -8
        self.rect = self.image.get_rect(midbottom = soil.rect.midbottom + pygame.math.Vector2(0,self.y_offset))
        self.z = LAYERS['ground plant']
        
        
    def grow(self):
        if self.check_watered(self.rect.center):
            self.age += self.grow_speed
            
            if int(self.age) > 0:
                self.z = LAYERS['main']
                self.hitbox = self.rect.copy().inflate(-26,self.rect.height * 0.4)
            
            if self.age >= self.max_age:
                self.age = self.max_age
                self.harvestable = True
            
            self.image=self.frames[int(self.age)]
            self.rect = self.image.get_rect(
                midbottom=self.soil.rect.midbottom + pygame.math.Vector2(0, self.y_offset)
            )            
           

class SoilLayer:
    
    def __init__(self, all_sprites, collision_sprites):
        
        # sprite groups
        self.all_sprites = all_sprites
        self.collision_sprites = collision_sprites
        self.soil_sprites = pygame.sprite.Group()
        self.water_sprites = pygame.sprite.Group()
        self.plant_sprites = pygame.sprite.Group()
        
        # graphics
        #self.soil_surf = pygame.image.load('project/graphics/soil/o.png')
        self.soil_surfs = import_folder_dict('project/graphics/soil/') 
        self.water_surfs = import_folder('project/graphics/soil_water/')
        
        #print(self.soil_surfs)
        
        self.create_soil_grid()
        self.create_hit_rects()
        
        #sounds
        # --------------------------------------------------
        # AUDIO DESACTIVADO TEMPORALMENTE PARA LA VERSIÃ“N WEB
        # --------------------------------------------------

        # self.hoe_sound = load_sound(
        #     resource_path('project/audio/hoe.wav')
        # )
        # self.hoe_sound.set_volume(0.3)

        # self.plant_sound = load_sound(
        #     resource_path('project/audio/plant.wav')
        # )
        # self.plant_sound.set_volume(0.2)
 
        
    def create_soil_grid(self):
        ground = pygame.image.load(resource_path('project/graphics/world/ground.png'))
        h_tiles, v_tiles = ground.get_width() // TITLE_SIZE, ground.get_height() // TITLE_SIZE
        print(h_tiles)
        print(v_tiles)
        
        self.grid = [ [[] for col in range (h_tiles)] for row in range(v_tiles)]
        print(self.grid)
        for x,y,_ in load_pygame(resource_path('project/data/map.tmx')).get_layer_by_name('Farmable').tiles(): #Usando _ Ignoramos el valor de ese valor
            self.grid[y][x].append('F')
        print(self.grid)
    
    def create_hit_rects(self):
        self.hit_rects = []
        
        for index_row, row in enumerate(self.grid):
            for index_col, cell in enumerate(row):
                if 'F' in cell: #Creamos un rectÃ¡ngulo para cada celda que tiene una F de farmeable, podemos ver el mapa en tile y en el array mostrado por consola (40x50) donde la mayor parte farmeable es mitad del mapa hacia abajo.
                    x = index_col * TITLE_SIZE
                    y = index_row * TITLE_SIZE
                    rect = pygame.Rect(x, y, TITLE_SIZE, TITLE_SIZE)
                    self.hit_rects.append(rect)

    def get_hit(self,point): #Cada vez que el jugador golpe con la azada
        for rect in self.hit_rects:
            if rect.collidepoint(point):  
                
                # Audio desactivado para Web
                # self.hoe_sound.play()
                
                x = rect.x // TITLE_SIZE
                y = rect.y // TITLE_SIZE
                
                if 'F' in self.grid[y][x]:
                    print('farmable')
                    self.grid[y][x].append('X')  # Nos dice que en este tile tenemos un soil patch            
                    self.create_soil_tiles()
                    
                    if self.raining:
                        self.water_all()
          
    def water(self, target_pos): # Calculamos si este target position choca con cualquiera de los soil sprites
             for soil_sprite in self.soil_sprites:
                  if soil_sprite.rect.collidepoint(target_pos):
                    print('soil tile watered')
                    
                    
                    # 1. AÃ±adir entrada a la grilla de soil -> 'W'
                    x = soil_sprite.rect.x // TITLE_SIZE
                    y = soil_sprite.rect.y // TITLE_SIZE
                    self.grid[y][x].append('W')
                   
                   
                    # 2. Crear sprite del agua
                    #1. Copy the position from the soil sprite
                    pos = soil_sprite.rect.topleft
                    #2. For the surface -> import the folder 
                    #3. Seleccionar una superficie aleatoriamente
                    surf = choice(self.water_surfs)
                    WaterTile(pos,surf, [self.all_sprites, self.water_sprites])
                    #4. Crear un nuevo grupo 'Water_sprites'
 
    def water_all(self):
        for index_row, row in enumerate(self.grid):
            for index_col, cell in enumerate(row):
                if 'X' in cell and 'W' not in cell: #Reviamos toda la grilla y revisamos si hay una X y si no tiene agua aÃºn
                    cell.append('W')
                    x = index_col * TITLE_SIZE
                    y = index_row * TITLE_SIZE
                    WaterTile(
                    pos=(x, y),
                    surf=choice(self.water_surfs),
                    groups=[self.all_sprites, self.water_sprites]  
                    )         
                
    def  remove_water(self):
        # 1. Destruimos todos los sprites de agua
        for sprite in self.water_sprites.sprites():
            sprite.kill()
        
        # 2. Limpiamos la grilla
        for row in self.grid:
            for cell in row:
                if 'W' in cell:
                    cell.remove('W')
                 
    def check_watered(self,pos):
        x = pos[0] // TITLE_SIZE
        y = pos[1] // TITLE_SIZE
        cell = self.grid[y][x]
        is_watered = 'W' in cell
        return is_watered
                 
                 
    def plant_seed(self,target_pos, seed):
        for soil_sprite in self.soil_sprites.sprites():
            if soil_sprite.rect.collidepoint(target_pos):
                
                # Audio desactivado para Web
                    # self.plant_sound.play()
                    # self.plant_sound.set_volume(0.1)

                x = soil_sprite.rect.x // TITLE_SIZE   
                y = soil_sprite.rect.y // TITLE_SIZE  
                if 'P' not in self.grid[y][x]:
                    self.grid[y][x].append('P')
                    Plant(seed, [self.all_sprites, self.plant_sprites, self.collision_sprites], soil_sprite, self.check_watered)
                 
                    
    def update_plants(self):
        for plant in self.plant_sprites.sprites():
            plant.grow()
                        
                    
    def create_soil_tiles(self):
        self.soil_sprites.empty() #Eliminamos los sprites del soil
        for index_row, row in enumerate(self.grid): #Los dibujamos desde 0
            for index_col, cell in enumerate(row):
                if 'X' in cell:
                    
                    # tile options
                    t = 'X' in self.grid[index_row - 1][index_col]
                    b = 'X' in self.grid[index_row +1][index_col]
                    r = 'X' in row[index_col + 1]
                    l = 'X' in row[index_col - 1]
                    
                    tile_type = 'o'
                    
                    # all sides
                    if all((t,r,b,l)): tile_type = 'x'
                    
                    # horizontal tiles only
                    if l and not any((t,r,b)): tile_type = 'r' #si un tile solo tiene tile a la izquierda queremos que el tipo de tile sea el de la derecha
                    if r and not any((t,l,b)): tile_type = 'l'
                    if r and l and not any((t,b)): tile_type = 'lr'
                    
                    # vertical only
                    if t and not any ((r,l,b)): tile_type = 'b'
                    if b and not any ((r,l,t)): tile_type = 't'
                    if b and t and not any ((r,l)): tile_type = 'tb'
                    
                    
                    # corners
                    if l and b and not any ((t,r)): tile_type = 'tr'
                    if r and b and not any ((t,l)): tile_type = 'tl'
                    if l and t and not any ((b,r)): tile_type = 'br'
                    if r and t and not any ((b,l)): tile_type = 'bl'
                    
                    
                    # T shapes
                    if all((t,b,r)) and not l: tile_type = 'tbr'
                    if all((t,b,l)) and not r: tile_type = 'tbl'
                    if all((l,r,t)) and not b: tile_type = 'lrb'
                    if all((l,r,b)) and not t: tile_type = 'lrt'
                    
                    SoilTile(
                        pos = (index_col*TITLE_SIZE, index_row * TITLE_SIZE),
                        surf = self.soil_surfs[tile_type],
                        groups = [self.all_sprites, self.soil_sprites])       
