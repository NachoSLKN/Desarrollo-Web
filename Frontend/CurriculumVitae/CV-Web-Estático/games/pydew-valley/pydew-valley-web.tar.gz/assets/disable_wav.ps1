# Deshabilita todos los archivos .wav de project\audio

$audioFolder = ".\project\audio"

Get-ChildItem $audioFolder -Filter *.wav | ForEach-Object {

    $newName = "$($_.FullName).disabled"

    Rename-Item $_.FullName $newName

    Write-Host "Renombrado: $($_.Name) -> $($_.Name).disabled"
}

Write-Host ""
Write-Host "Todos los WAV han sido deshabilitados."