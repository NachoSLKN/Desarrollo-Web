$audioFolder = ".\project\audio"

Get-ChildItem $audioFolder -Filter *.mp3.disabled | ForEach-Object {

    $newName = $_.Name -replace '\.disabled$',''

    Rename-Item $_.FullName $newName

    Write-Host "Restaurado:" $_.Name "->" $newName
}

Write-Host ""
Write-Host "Todos los MP3 han sido restaurados."